# Graph audit/export: explicit helper reuse

Three required graph-audit-9b conditions attempted once each. All failures and timeouts retained.

Required case pattern observed: True. One fresh run in each required condition; no automatic retries or formal repetitions. The optional 9B without-skill control is not scheduled in this version.

| Model | Skill | Functional success | Actual skill use | Qualified success | Checks | Seconds | Commands | Failed |
|---|---|---|---|---|---:|---:|---:|---:|
| qwen3.5:9b | True | True | True | True | 10/10 | 39.033 | 21 | 1 |
| qwen3.5:27b | False | True | None | True | 10/10 | 126.039 | 10 | 2 |
| qwen3.5:27b | True | True | True | True | 10/10 | 178.625 | 15 | 1 |

Candidate selection was specified before this batch: V3 produced W1 4B 9/10 with empty SVGs, S0 27B 10/10, and S1 27B 10/10 with observed helper use. These records remain separate and unchanged.

This batch replaces only the weaker candidate with qwen3.5:9b and runs all three required conditions fresh. V3 prompt, input, expected outputs, checker, helper observer and public skill are byte-identical. The effective custom catalog preserves both previous entries and adds a 9B entry with identical generic harness settings except model names. It is study metadata, not native Qwen metadata. The base harness and its validated catalog are not edited.

All conditions receive the same explicit-invocation prompt and 360-second agent budget. There are no automatic retries, no task-failure gate and no reused model outputs. The optional weaker without-skill trial is omitted prospectively. Older 4B trials are search history, not a 9B baseline.

Functional success, skill reading, and executed helper methods are reported separately. Qualification requires correctness, clean completion and integrity, plus an observed skill read and real helper use when supplied. The prompt requests four methods; inspect method observation, source and traces for full instruction compliance. Independent verification and isolated byte-identical reexecution never repair the model program.

The optional download is preparation, not a model trial. Exact model digest, show metadata, loaded runtime and effective catalog hashes are archived. The models are candidate configurations; parameter counts alone do not prove capability ordering. Single observations, candidate selection, fixed order, loading and unspecified seeds limit inference. No stable success rate or causal skill benefit is claimed.
