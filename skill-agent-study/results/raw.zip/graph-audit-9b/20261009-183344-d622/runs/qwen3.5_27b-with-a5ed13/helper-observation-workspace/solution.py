#!/usr/bin/env python3
"""
Solution for dialogue graph audit and export task.
Reads graphs.json, audits each graph, writes audit.json, and exports valid graphs to JSON/SVG.
"""

import json
import sys
from pathlib import Path

# Add the dialogue_graph skill module to path
workspace_root = Path(__file__).parent
skill_module_path = workspace_root / ".agents/skills/dialogue-graph/scripts"
if str(skill_module_path) not in sys.path:
    sys.path.insert(0, str(skill_module_path))

from dialogue_graph import Graph, Node, Edge


def audit_graph(data: dict) -> dict:
    """
    Audit a dialogue graph dictionary.
    
    Args:
        data: Dictionary with 'nodes' and 'edges' keys.
        
    Returns:
        Dictionary with fields: valid (bool), errors ([str]), 
        node_count (int), edge_count (int).
    """
    # Build graph using the helper module
    graph = Graph.from_dict(data)
    
    # Validate using the helper
    errors = graph.validate()
    
    # Count nodes and edges from the supplied data
    node_count = len(data.get('nodes', []))
    edge_count = len(data.get('edges', []))
    
    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "node_count": node_count,
        "edge_count": edge_count
    }


def main():
    """Main entry point."""
    workspace = Path(__file__).parent
    
    # Read graphs.json
    graphs_path = workspace / "graphs.json"
    with open(graphs_path, encoding='utf-8') as f:
        records = json.load(f)
    
    audit_results = []
    valid_ids = []
    
    for record in records:
        graph_id = record["id"]
        graph_data = record["graph"]
        
        # Audit the graph
        audit_result = audit_graph(graph_data)
        
        # Store result
        audit_results.append({
            "id": graph_id,
            "valid": audit_result["valid"],
            "errors": audit_result["errors"],
            "node_count": audit_result["node_count"],
            "edge_count": audit_result["edge_count"]
        })
        
        # Track valid graphs for export
        if audit_result["valid"]:
            valid_ids.append(graph_id)
    
    # Write audit.json
    audit_path = workspace / "audit.json"
    with open(audit_path, 'w', encoding='utf-8') as f:
        json.dump(audit_results, f, indent=2)
    
    # Export valid graphs to JSON and SVG
    for record in records:
        graph_id = record["id"]
        graph_data = record["graph"]
        
        if not audit_graph(graph_data)["valid"]:
            continue
        
        # Build the Graph object
        graph = Graph.from_dict(graph_data)
        
        # Export to JSON (<id>.json)
        json_path = workspace / f"{graph_id}.json"
        with open(json_path, 'w', encoding='utf-8') as f:
            f.write(graph.to_json())
        
        # Export to SVG (<id>.svg) using visualize
        svg_base_path = str(workspace / graph_id)
        graph.visualize(svg_base_path, format='svg')
    
    print("Audit complete.")
    print(f"  - audit.json: {audit_path}")
    for vid in valid_ids:
        print(f"  - {vid}.json: exported")
        print(f"  - {vid}.svg: exported")


if __name__ == "__main__":
    main()
