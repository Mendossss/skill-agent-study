#!/usr/bin/env python3
"""
Solution for batch dialogue graph audit and export.
Reads graphs.json, validates each graph, writes audit.json and outputs for valid graphs.
"""

import json
import os
from typing import Any

# External terminal - allowed as a missing target only
END_TERMINAL = "End"


def audit_graph(data: dict) -> dict:
    """
    Audit a dialogue graph dictionary.
    
    Args:
        data: A dict containing 'nodes' and 'edges' keys with the graph structure.
        
    Returns:
        Dict with keys: valid (bool), errors (list of str), node_count (int), edge_count (int)
    """
    nodes = data.get("nodes", [])
    edges = data.get("edges", [])
    
    # Build set of node IDs
    node_ids = {node["id"] for node in nodes}
    
    errors = []
    
    # Check each edge for valid source and target
    for edge in edges:
        from_id = edge.get("from")
        to_id = edge.get("to")
        
        # Check source - must exist, End is NOT allowed as a missing source
        if from_id not in node_ids:
            errors.append(f"Edge source '{from_id}' not found")
        
        # Check target - must exist OR be the external terminal End
        if to_id != END_TERMINAL and to_id not in node_ids:
            errors.append(f"Edge target '{to_id}' not found")
    
    valid = len(errors) == 0
    
    return {
        "valid": valid,
        "errors": errors,
        "node_count": len(nodes),
        "edge_count": len(edges)
    }


def graph_to_svg(graph_data: dict, output_path: str) -> None:
    """
    Generate an SVG diagram for a graph using Graphviz via dot.
    
    Args:
        graph_data: Dict with 'nodes' and 'edges' keys.
        output_path: Path to write the SVG file (without .svg extension).
    """
    nodes = graph_data.get("nodes", [])
    edges = graph_data.get("edges", [])
    
    # Build DOT representation
    dot_lines = ["digraph G {"]
    
    # Add nodes with appropriate shapes
    for node in nodes:
        node_id = node["id"]
        node_type = node.get("type", "line")
        
        # Escape the text content for DOT
        text = node.get("text", "")
        speaker = node.get("speaker", "")
        label = f"{speaker}: {text}" if speaker else text
        
        # Escape quotes and backslashes in label
        label_escaped = label.replace('"', '\\"').replace('\n', '\\n')
        
        shape = "diamond" if node_type == "choice" else "box"
        dot_lines.append(f'  "{node_id}" [shape={shape}, label="{label_escaped}"];')
    
    # Add edges - include End terminal if it's a target
    for edge in edges:
        from_id = edge["from"]
        to_id = edge["to"]
        
        # If target is End, add it as a special node (no shape, just a label)
        if to_id == END_TERMINAL and any(
            n.get("id") != END_TERMINAL for n in nodes
        ):
            # Add End node with default box shape
            dot_lines.append(f'  "{END_TERMINAL}" [label="End"];')
        
        # Escape edge text
        edge_text = edge.get("text", "")
        edge_text_escaped = edge_text.replace('"', '\\"').replace('\n', '\\n')
        
        if edge_text:
            dot_lines.append(f'  "{from_id}" -> "{to_id}" [label="{edge_text_escaped}"];')
        else:
            dot_lines.append(f'  "{from_id}" -> "{to_id}";')
    
    dot_lines.append("}")
    dot_source = "\n".join(dot_lines)
    
    # Write DOT to a temp file and call graphviz
    import tempfile
    import subprocess
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.dot', delete=False) as f:
        f.write(dot_source)
        dot_path = f.name
    
    try:
        # Call dot to generate SVG
        svg_output_path = output_path + ".svg"
        result = subprocess.run(
            ["dot", "-Tsvg", "-o", svg_output_path, dot_path],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            raise RuntimeError(f"Graphviz failed: {result.stderr}")
    finally:
        os.unlink(dot_path)


def graph_to_json(graph_data: dict, output_path: str) -> None:
    """
    Write the complete original nodes and edges to a JSON file.
    
    Args:
        graph_data: Dict with 'nodes' and 'edges' keys.
        output_path: Path to write the JSON file (without .json extension).
    """
    # Preserve all text and action tags exactly - just nodes and edges
    export_data = {
        "nodes": graph_data.get("nodes", []),
        "edges": graph_data.get("edges", [])
    }
    
    with open(output_path + ".json", 'w', encoding='utf-8') as f:
        json.dump(export_data, f, indent=2, ensure_ascii=False)


def main():
    # Read input graphs.json
    input_path = "graphs.json"
    
    with open(input_path, 'r', encoding='utf-8') as f:
        records = json.load(f)
    
    # Process each record
    audit_results = []
    
    for record in records:
        graph_id = record["id"]
        graph_data = record["graph"]
        
        # Audit the graph
        audit_result = audit_graph(graph_data)
        
        # Build result record
        result_record = {
            "id": graph_id,
            "valid": audit_result["valid"],
            "errors": audit_result["errors"],
            "node_count": audit_result["node_count"],
            "edge_count": audit_result["edge_count"]
        }
        audit_results.append(result_record)
        
        # For valid graphs only: export JSON and SVG
        if audit_result["valid"]:
            json_output_path = graph_id
            graph_to_json(graph_data, json_output_path)
            
            svg_output_path = graph_id
            graph_to_svg(graph_data, svg_output_path)
    
    # Write audit.json
    with open("audit.json", 'w', encoding='utf-8') as f:
        json.dump(audit_results, f, indent=2, ensure_ascii=False)
    
    print(f"Audited {len(records)} graphs. Results written to audit.json")
    for result in audit_results:
        status = "VALID" if result["valid"] else "INVALID"
        print(f"  {result['id']}: {status} ({result['node_count']} nodes, {result['edge_count']} edges)")
        if result['errors']:
            for err in result['errors']:
                print(f"    - {err}")


if __name__ == "__main__":
    main()
