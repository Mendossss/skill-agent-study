import json
import os

# Try to import the dialogue_graph skill if available
try:
    from dialogue_graph import Graph
    USE_SKILL = True
except ImportError:
    USE_SKILL = False


def audit_graph(data: dict) -> dict:
    """
    Audit a dialogue graph for validity.
    
    Args:
        data: A dictionary with 'nodes' and 'edges' keys.
        
    Returns:
        dict with fields: valid, errors, node_count, edge_count
    """
    if not USE_SKILL:
        # Fallback implementation if skill is not available
        nodes = {n['id'] for n in data.get('nodes', [])}
        edges = data.get('edges', [])
        errors = []
        
        for edge in edges:
            source = edge.get('from')
            target = edge.get('to')
            
            # Check source - missing sources are always errors
            if source not in nodes:
                errors.append(f"Edge source '{source}' not found")
            
            # Check target - missing targets are allowed only if target is "End"
            if target != 'End' and target not in nodes:
                errors.append(f"Edge target '{target}' not found")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "node_count": len(nodes),
            "edge_count": len(edges)
        }
    
    # Use the skill helper if available
    graph = Graph.from_dict(data)
    errors = graph.validate()
    
    nodes = data.get('nodes', [])
    edges = data.get('edges', [])
    
    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "node_count": len(nodes),
        "edge_count": len(edges)
    }


def main():
    workspace_dir = os.getcwd()
    graphs_path = os.path.join(workspace_dir, 'graphs.json')
    audit_output = os.path.join(workspace_dir, 'audit.json')
    
    # Read graphs.json
    with open(graphs_path, 'r', encoding='utf-8') as f:
        records = json.load(f)
    
    audit_results = []
    valid_graph_ids = []
    
    for record in records:
        graph_id = record['id']
        graph_data = record['graph']
        
        result = audit_graph(graph_data)
        audit_results.append({
            "id": graph_id,
            "valid": result["valid"],
            "errors": result["errors"],
            "node_count": result["node_count"],
            "edge_count": result["edge_count"]
        })
        
        if result["valid"]:
            valid_graph_ids.append(graph_id)
    
    # Write audit.json
    with open(audit_output, 'w', encoding='utf-8') as f:
        json.dump(audit_results, f, indent=2)
    
    # For valid graphs only, write <id>.json and <id>.svg
    for graph_id in valid_graph_ids:
        record = next(r for r in records if r['id'] == graph_id)
        graph_data = record['graph']
        
        # Write JSON file with original nodes and edges (ignore list order)
        json_path = os.path.join(workspace_dir, f'{graph_id}.json')
        # Preserve the exact original structure from input
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(graph_data, f, indent=2)
        
        # Generate SVG using Graph.visualize if skill is available
        svg_path = os.path.join(workspace_dir, f'{graph_id}.svg')
        if USE_SKILL and hasattr(Graph, 'visualize'):
            graph_obj = Graph.from_dict(graph_data)
            graph_obj.visualize(svg_path[:-4], format='svg')
    
    print(f"Processed {len(records)} records.")
    print(f"Valid graphs: {len(valid_graph_ids)}")
    print(f"Audit report written to: {audit_output}")


if __name__ == '__main__':
    main()
