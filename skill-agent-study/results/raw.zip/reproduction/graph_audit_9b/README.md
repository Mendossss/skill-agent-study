# Prospective 9B candidate batch

After V3: 4B with skill 9/10 (empty diagrams), 27B without 10/10,
27B with 10/10 and real helper use. Those results remain unchanged.
This batch selects 9B as a new candidate weaker configuration and runs
9B with skill, 27B without, 27B with: three fresh trials, once each.
It does not assume that 9B succeeds or is universally weaker than 27B.

V3 task.txt, graphs.json, expected.json, check.py and observe_helper.py are
byte-identical. Public skill and validated revision-7 base stay unchanged.
The custom catalog adds only a generic 9B entry, copying 4B harness metadata
except names. Both old entries are unchanged. The runtime command uses
this separate catalog; the base catalog is never edited. All conditions
receive the same prompt, tools, sandbox, context request and 360s budget.

If 9B is absent, ollama pull qwen3.5:9b runs once, up to 600 seconds,
with download logs. It is preparation, not an experimental observation.
The official model tag was checked at https://ollama.com/library/qwen3.5:9b.
Actual local digest, metadata, runtime/context and parameters are recorded;
the script does not assume a particular quantization/backend from the name.
Models allow 18 minutes total, plus up to five minutes verification/observation
and any model download. Normal runs can be shorter. No automatic retries
or task-failure gates. All three trials are attempted after preparation.

Functional correctness and helper use are separate. Qualification requires
all functional checks, clean completion, integrity and real skill read/use
when supplied. Inspect all four requested methods in source and observation.
The optional 9B without-skill control is not scheduled prospectively.
Original task, not a SkillsBench benchmark score. Single selected trials
cannot establish stable success probabilities or a causal skill effect.

Run the self-contained run_graph_audit_9b.py on the existing validated Mac.
Older directories and raw archives are preserved. No existing credentials
are edited. The original skill is Apache-2.0, author scriptwonder, SkillsBench
commit 55bfe693f2a19f6b2f29aca3f54fe98b9d994668.
