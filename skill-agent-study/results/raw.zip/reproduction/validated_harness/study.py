#!/usr/bin/env python3
"""Run and independently grade a native-macOS adaptation of dialogue-parser."""
import argparse
import csv
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import re
import shutil
import signal
import subprocess
import sys
import time
import urllib.request
import uuid
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
DATA = Path.home() / 'nus-agent-study-results' / 'dialogue-parser'
SOURCE = ROOT / 'source'
REVISION = 'native-dialogue-7'


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def api(path, data=None):
    request = urllib.request.Request('http://127.0.0.1:11434' + path,
        data=None if data is None else json.dumps(data).encode(),
        headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.load(response)


def python_path():
    return ROOT / '.venv' / 'bin' / 'python'


def run_process(command, cwd, folder, stem, timeout, stdin=None, env=None):
    folder.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    timed_out, interrupted = False, False
    with (folder / (stem + '.stdout')).open('wb') as stdout, (folder / (stem + '.stderr')).open('wb') as stderr:
        process = subprocess.Popen(command, cwd=cwd, stdin=subprocess.PIPE,
            stdout=stdout, stderr=stderr, env=env, start_new_session=True)
        try:
            pending = stdin
            deadline = start + timeout
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise subprocess.TimeoutExpired(command, timeout)
                try:
                    process.communicate(pending, timeout=min(30, remaining))
                    break
                except subprocess.TimeoutExpired:
                    pending = None
                    if time.monotonic() >= deadline:
                        raise
                    print(f'  {stem}: {int(time.monotonic() - start)}s elapsed; logs are being saved.', flush=True)
        except (subprocess.TimeoutExpired, KeyboardInterrupt) as exc:
            interrupted = isinstance(exc, KeyboardInterrupt)
            timed_out = not interrupted
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
    return {'exit_code': process.returncode, 'timed_out': timed_out, 'interrupted': interrupted,
            'elapsed_s': round(time.monotonic() - start, 3)}


def clean_env(work=None, with_skill=False):
    env = os.environ.copy()
    for key in ('PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP', 'PYTEST_ADDOPTS'):
        env.pop(key, None)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
    env['PATH'] = str(python_path().parent) + os.pathsep + env.get('PATH', '')
    if work is not None:
        temp = work / '.tmp'
        temp.mkdir(parents=True, exist_ok=True)
        for key in ('TMPDIR', 'TMP', 'TEMP'):
            env[key] = str(temp)
        env['TMPPREFIX'] = str(temp / 'zsh')
    if with_skill:
        env['PYTHONPATH'] = str(work / '.agents/skills/dialogue-graph/scripts')
    return env


def config_flags(work, grading=False, extra_read=()):
    """Read only the workspace and runtime; keep controller/source/other runs private."""
    read_paths = {ROOT / '.venv', Path(sys.base_prefix).resolve(), python_path().resolve().parent.parent}
    for directory in ('/opt/homebrew', '/usr/local', '/usr/lib', '/usr/share', '/bin', '/sbin', '/System', '/Library/Frameworks'):
        if Path(directory).exists():
            read_paths.add(Path(directory))
    if grading:
        read_paths.update({SOURCE / 'verifier', ROOT / 'contract_check.py'})
    filesystem = {
        ':root': 'deny', ':minimal': 'read', ':tmpdir': 'write', ':slash_tmp': 'deny',
        str(work): 'write',
        str(work / '.tmp'): 'write',
    }
    if not grading:
        filesystem[str(work / 'script.txt')] = 'read'
        filesystem[str(work / '.agents')] = 'read'
    for path in read_paths | set(extra_read):
        filesystem[str(path)] = 'read'
    entries = {'default_permissions': 'study', 'permissions.study.extends': ':workspace',
               'permissions.study.network.enabled': False}
    flags = []
    for key, value in entries.items():
        flags += ['-c', key + '=' + json.dumps(value)]
    # CLI dotted keys split at dots without interpreting quoted path components.
    # Put the complete filesystem map in one TOML value so paths retain their actual keys.
    table = '{' + ','.join(json.dumps(k) + '=' + json.dumps(v)
                           for k, v in sorted(filesystem.items())) + '}'
    flags += ['-c', 'permissions.study.filesystem=' + table]
    return flags


def sandbox_command(codex, work, command, grading=False, extra_read=()):
    flags = config_flags(work, grading, extra_read)
    return [codex, 'sandbox', '--permission-profile', 'study', '--cd', str(work)] + flags + ['--'] + command


def external_skills(work):
    bases = {Path.home() / '.agents/skills', Path.home() / '.codex/skills'}
    for parent in work.parents:
        bases.add(parent / '.agents/skills')
    paths = set()
    for base in bases:
        if base.exists():
            paths.update(str(p.resolve()) for p in base.rglob('SKILL.md'))
    return sorted(paths)


def isolated_config(work, with_skill):
    pairs = {
        # A process-local store does not load the user's stale ChatGPT login.
        # Ollama is unauthenticated; no existing credentials are changed.
        'cli_auth_credentials_store': 'ephemeral',
        'model_catalog_json': str(ROOT / 'local_models.json'),
        'model_reasoning_effort': 'none',
        'web_search': 'disabled', 'model_context_window': 65536,
        'features.apps': False,
        'features.plugins': False, 'features.remote_models': False,
        'features.memories': False, 'features.multi_agent': False,
        'skills.bundled.enabled': False, 'memories.use_memories': False,
        'memories.generate_memories': False, 'project_doc_max_bytes': 0,
        'shell_environment_policy.inherit': 'core',
        'shell_environment_policy.set.PATH': clean_env(work)['PATH'],
        'shell_environment_policy.set.PYTHONDONTWRITEBYTECODE': '1',
        'shell_environment_policy.set.TMPDIR': str(work / '.tmp'),
        'shell_environment_policy.set.TMP': str(work / '.tmp'),
        'shell_environment_policy.set.TEMP': str(work / '.tmp'),
        'shell_environment_policy.set.TMPPREFIX': str(work / '.tmp/zsh'),
        'developer_instructions': (
            'This task runs in a native macOS workspace. All /app paths in the task refer '
            'to the current working directory. Python dependencies are already installed; '
            f'use {python_path()} to run Python. Graphviz is available. '
            'Use only the workspace and installed runtime. Do not install dependencies or access the network.'
        ),
    }
    if with_skill:
        pairs['shell_environment_policy.set.PYTHONPATH'] = str(work / '.agents/skills/dialogue-graph/scripts')
    else:
        pairs['shell_environment_policy.set.PYTHONPATH'] = ''
    flags = config_flags(work)
    for key, value in pairs.items():
        flags += ['-c', key + '=' + json.dumps(value)]
    disabled = external_skills(work)
    # A TOML inline-table array, supplied as one argv element without shell interpolation.
    if disabled:
        value = '[' + ','.join('{path=' + json.dumps(path) + ',enabled=false}' for path in disabled) + ']'
        flags += ['-c', 'skills.config=' + value]
    return flags, disabled


def verify_sources():
    manifest = json.loads((ROOT / 'source_manifest.json').read_text())
    for relative, expected in manifest['sha256'].items():
        if sha(ROOT / relative) != expected:
            raise RuntimeError('Source changed: ' + relative)
    return manifest


def environment():
    codex = shutil.which('codex')
    if not codex:
        raise RuntimeError('codex is missing; install with brew install --cask codex')
    if not python_path().exists():
        raise RuntimeError('Run python3 study.py setup first.')
    if not shutil.which('dot'):
        raise RuntimeError('Graphviz is missing; run brew install graphviz')
    return {
        'codex_path': codex,
        'codex_version': subprocess.check_output([codex, '--version'], text=True, timeout=30).strip(),
        'ollama_version': api('/api/version'), 'host': platform.platform(),
        'python_version': subprocess.check_output([str(python_path()), '--version'], text=True).strip(),
        'dot_version': subprocess.run(['dot', '-V'], capture_output=True, text=True).stderr.strip(),
        'revision': REVISION, 'source': verify_sources(),
        'controller_sha256': sha(Path(__file__)), 'contract_sha256': sha(ROOT / 'contract_check.py'),
        'catalog_sha256': sha(ROOT / 'local_models.json'),
        'prompt_sha256': sha(ROOT / 'task_prompt.txt'),
    }


def selfcheck(codex, folder):
    work = folder / 'workspace'
    work.mkdir(parents=True)
    (work / 'script.txt').write_text('sandbox test\n')
    canary = folder / 'private-canary.txt'
    canary.write_text('controller-only\n')
    code = (
        'from pathlib import Path; import socket\n'
        'assert Path("script.txt").read_text() == "sandbox test\\n"\n'
        'Path("writable.txt").write_text("ok")\n'
        f'p=Path({str(canary)!r})\n'
        'try: p.read_text()\n'
        'except PermissionError: pass\n'
        'else: raise AssertionError("outside read was allowed")\n'
        'try: p.write_text("changed")\n'
        'except PermissionError: pass\n'
        'else: raise AssertionError("outside write was allowed")\n'
        'try:\n'
        ' s=socket.socket(); s.settimeout(2); s.connect(("127.0.0.1",11434))\n'
        'except OSError as e: assert e.errno in (1,13), "network failed without proof of a permission denial"\n'
        'else: raise AssertionError("command network was allowed")\n'
        'print("ISOLATION_PASS")\n'
    )
    command = sandbox_command(codex, work, [str(python_path()), '-c', code])
    result = run_process(command, work, folder, 'isolation', 60, env=clean_env(work))
    result['pass'] = (result['exit_code'] == 0 and not result['timed_out']
                      and not result.get('interrupted')
                      and 'ISOLATION_PASS' in (folder/'isolation.stdout').read_text())
    result['command'] = command
    if not result['pass']:
        dump(folder / 'isolation.json', result)
        raise RuntimeError('Sandbox self-check failed. No model run started. See ' + str(folder / 'isolation.stderr')
                           + '\n' + (folder / 'isolation.stderr').read_text(errors='replace')[-4000:])
    # zsh uses TMPPREFIX for heredocs; Python uses TMPDIR. The earlier file-write probe did not
    # exercise this path. The payload is deliberately larger than a pipe buffer.
    payload = ('#' + 'x' * 24000 + '\n'
               'import os, tempfile\nfrom pathlib import Path\n'
               f'assert Path(tempfile.gettempdir()).resolve() == Path({str(work / ".tmp")!r}).resolve()\n'
               'with tempfile.TemporaryFile() as f: f.write(b"temporary writes work")\n'
               'print("HEREDOC_PASS")\n')
    shell = 'cat > heredoc_probe.py <<\'PY_CODE\'\n' + payload + 'PY_CODE\n' + str(python_path()) + ' heredoc_probe.py\n'
    heredoc = run_process(sandbox_command(codex, work, ['/bin/zsh', '-lc', shell]),
        work, folder, 'heredoc', 60, env=clean_env(work))
    result['heredoc_check'] = heredoc
    result['pass'] = (result['pass'] and heredoc['exit_code'] == 0 and not heredoc['timed_out']
                      and 'HEREDOC_PASS' in (folder / 'heredoc.stdout').read_text())
    dump(folder / 'isolation.json', result)
    if not result['pass']:
        raise RuntimeError('Large-heredoc self-check failed. See ' + str(folder / 'heredoc.stderr')
                           + '\n' + (folder / 'heredoc.stderr').read_text(errors='replace')[-2000:])
    return result


def grade(codex, work, folder, with_skill):
    snapshot = folder / 'verification-workspace'
    shutil.copytree(work, snapshot)
    env = clean_env(snapshot, with_skill)
    # Keep collection inside the permitted root. An absolute test path outside
    # rootdir makes pytest scan ancestors such as /Users before importing it.
    # This is a byte-identical copy, created only after the model exits.
    verifier = snapshot / '.verification' / 'test_outputs.py'
    verifier.parent.mkdir()
    shutil.copyfile(SOURCE / 'verifier/test_outputs.py', verifier)
    if sha(verifier) != sha(SOURCE / 'verifier/test_outputs.py'):
        raise RuntimeError('Verifier copy differs from the pinned source.')
    report = snapshot / 'upstream.xml'
    command = sandbox_command(codex, snapshot,
        [str(python_path()), '-m', 'pytest', '-q', '--capture=sys', '-p', 'no:cacheprovider', '--noconftest',
         '-c', '/dev/null', '--rootdir=' + str(snapshot), '--confcutdir=' + str(snapshot),
         '.verification/test_outputs.py', '--junitxml=' + str(report)], grading=True)
    execution = run_process(command, snapshot, folder, 'upstream', 120, env=env)
    counts = {'passed': 0, 'failed': 0, 'errors': 0, 'skipped': 0, 'total': 0}
    if report.exists():
        for case in ET.parse(report).getroot().iter('testcase'):
            counts['total'] += 1
            key = 'failed' if case.find('failure') is not None else 'errors' if case.find('error') is not None else 'skipped' if case.find('skipped') is not None else 'passed'
            counts[key] += 1
        shutil.copyfile(report, folder / 'upstream.xml')
    upstream_pass = (execution['exit_code'] == 0 and not execution['timed_out']
                     and counts['total'] == 35 and counts['passed'] == counts['total'])
    contract_path = snapshot / 'contract.json'
    command = sandbox_command(codex, snapshot,
        [str(python_path()), str(ROOT / 'contract_check.py'), str(snapshot), str(contract_path)],
        grading=True, extra_read=[work / '.agents'] if with_skill else ())
    contract_execution = run_process(command, snapshot, folder, 'contract', 60, env=env)
    contract = json.loads(contract_path.read_text()) if contract_path.exists() else {'pass': False, 'error': 'No contract report'}
    contract['pass'] = bool(contract.get('pass')) and contract_execution['exit_code'] == 0 and not contract_execution['timed_out']
    syntax = run_process(sandbox_command(codex, snapshot, ['dot', '-Tdot', 'dialogue.dot'], grading=True),
        snapshot, folder, 'dot-syntax', 60, env=env)
    result = {'verifier_sha256': sha(verifier),
              'upstream': {**counts, **execution, 'pass': upstream_pass,
                          'score': counts['passed'] / counts['total'] if counts['total'] else 0},
              'contract': {**contract, 'execution': contract_execution},
              'dot_syntax': {**syntax, 'pass': syntax['exit_code'] == 0 and not syntax['timed_out']}}
    dump(folder / 'verification.json', result)
    return result


def read_events(path):
    events, bad = [], 0
    for line in path.read_text(errors='replace').splitlines():
        if not line.strip():
            continue
        try:
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError('event is not an object')
            events.append(value)
        except ValueError:
            bad += 1
    return events, bad


def agent_command(info, model, work, with_skill):
    flags, disabled = isolated_config(work, with_skill)
    command = [info['codex_path'], '--no-daemon', '-a', 'never', 'exec', '--ignore-user-config',
        '--oss', '--local-provider', 'ollama', '--model', model, '--skip-git-repo-check',
        '--ephemeral', '--json', '--cd', str(work)] + flags + ['-']
    return command, disabled


def nonfatal_event_warning(message):
    # Codex emits these informational notices as item.type=error. Keep all
    # messages in the record, but do not equate a notice with a failed turn.
    return ((message.startswith('Model metadata for `') and 'Defaulting to fallback metadata' in message)
            or message.startswith('Heads up: Long threads and multiple compactions'))


def run_trial(model, with_skill, phase, repeat, timeout, env_info, batch):
    name = f'{phase}-{repeat}-{model.replace(":", "_")}-' + ('with' if with_skill else 'without') + '-' + uuid.uuid4().hex[:6]
    folder = DATA / 'runs' / name
    work = folder / 'workspace'
    work.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(SOURCE / 'environment/script.txt', work / 'script.txt')
    if with_skill:
        shutil.copytree(SOURCE / 'environment/skills/dialogue-graph', work / '.agents/skills/dialogue-graph')
    installed = next((m for m in api('/api/tags')['models'] if m.get('name') == model), None)
    if installed is None:
        raise RuntimeError('Model is not installed: ' + model)
    info = api('/api/show', {'model': model})
    command, disabled = agent_command(env_info, model, work, with_skill)
    prompt = (ROOT / 'task_prompt.txt').read_bytes()
    manifest = {'run_id': name, 'phase': phase, 'repeat': repeat, 'batch': batch,
        'model': model, 'model_digest': installed['digest'], 'model_details': installed.get('details'),
        'model_parameters': info.get('parameters'), 'with_skill': with_skill,
        'timeout_s': timeout, 'started_at': dt.datetime.now().astimezone().isoformat(),
        'input_sha256': sha(work / 'script.txt'), 'prompt_sha256': hashlib.sha256(prompt).hexdigest(),
        'task_variant': 'terminal-sentinel-clarification-v1', 'prompt_text': prompt.decode('utf-8'),
        'environment': env_info, 'command': command, 'disabled_external_skills': disabled,
        'adaptation': 'native macOS; /app mapped to cwd; shared terminal-sentinel representation clarified; upstream source and test assertions unchanged'}
    dump(folder / 'manifest.json', manifest)
    dump(folder / 'model-show.json', info)
    print('\nRUN ' + name, flush=True)
    execution = run_process(command, work, folder, 'agent', timeout, stdin=prompt,
                            env=clean_env(work, with_skill))
    (folder / 'agent.stdout').rename(folder / 'events.jsonl')
    events, bad = read_events(folder / 'events.jsonl')
    items = [e.get('item', {}) for e in events if e.get('type') == 'item.completed']
    commands = [i for i in items if i.get('type') == 'command_execution']
    errors = [i.get('message', '') for i in items if i.get('type') == 'error']
    fatal_errors = [message for message in errors if not nonfatal_event_warning(message)]
    stderr = (folder / 'agent.stderr').read_text(errors='replace')
    auth_error = any(s in stderr for s in ('HTTP 401', 'Failed to refresh token', 'unauthorized_unknown'))
    completed = any(e.get('type') == 'turn.completed' for e in events)
    input_ok = (work / 'script.txt').exists() and sha(work / 'script.txt') == manifest['input_sha256']
    skill_unchanged = True
    if with_skill:
        source_skill = SOURCE / 'environment/skills/dialogue-graph'
        for path in source_skill.rglob('*'):
            if path.is_file():
                copied = work / '.agents/skills/dialogue-graph' / path.relative_to(source_skill)
                skill_unchanged = skill_unchanged and copied.exists() and sha(copied) == sha(path)
    artifact_hashes = {str(p.relative_to(work)): sha(p) for p in work.rglob('*') if p.is_file()}
    dump(folder / 'artifact_hashes.json', artifact_hashes)
    verification = grade(env_info['codex_path'], work, folder, with_skill)
    tool_ok = execution['exit_code'] == 0 and not execution['timed_out'] and not execution['interrupted'] and completed
    score_pass = verification['upstream']['pass']
    full_pass = score_pass and verification['contract']['pass'] and verification['dot_syntax']['pass'] and input_ok
    result = {'run_id': name, 'phase': phase, 'model': model, 'with_skill': with_skill,
        'repeat': repeat, **execution, 'turn_completed': completed, 'input_unchanged': input_ok,
        'skill_unchanged': skill_unchanged,
        'upstream_pass': score_pass, 'upstream_score': verification['upstream']['score'],
        'contract_pass': verification['contract']['pass'], 'dot_syntax_pass': verification['dot_syntax']['pass'],
        'task_pass': full_pass, 'tool_execution_ok': tool_ok, 'auth_error': auth_error,
        'unparsed_event_lines': bad, 'item_errors': errors, 'fatal_event_errors': fatal_errors,
        'eligible_success': full_pass and tool_ok and skill_unchanged and not auth_error and bad == 0 and not fatal_errors,
        'command_calls': len(commands), 'failed_commands': sum(c.get('exit_code') != 0 for c in commands),
        'file_change_events': sum(i.get('type') == 'file_change' for i in items),
        'skill_mentions_in_commands': sum('dialogue-graph' in c.get('command', '') or 'dialogue_graph' in c.get('command', '') for c in commands),
        'usage': [e.get('usage') for e in events if e.get('type') == 'turn.completed'],
        'finished_at': dt.datetime.now().astimezone().isoformat()}
    try:
        result['loaded_model'] = api('/api/ps')
    except (OSError, ValueError):
        result['loaded_model'] = None
    dump(folder / 'result.json', result)
    print(json.dumps(result, indent=2, ensure_ascii=False), flush=True)
    summarize()
    if execution['interrupted']:
        raise RuntimeError('Interrupted by user. This run is saved; no further model run will start.')
    return result


def summarize():
    rows = [json.loads(p.read_text()) for p in sorted((DATA / 'runs').glob('*/result.json'))]
    DATA.mkdir(parents=True, exist_ok=True)
    keys = ['run_id', 'phase', 'model', 'with_skill', 'repeat', 'eligible_success', 'task_pass',
            'upstream_pass', 'upstream_score', 'contract_pass', 'dot_syntax_pass', 'elapsed_s',
            'command_calls', 'failed_commands', 'file_change_events', 'skill_mentions_in_commands',
            'exit_code', 'timed_out', 'auth_error', 'revision', 'controller_sha256', 'catalog_sha256']
    with (DATA / 'results.csv').open('w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=keys, extrasaction='ignore')
        writer.writeheader()
        for row in rows:
            manifest = json.loads((DATA / 'runs' / row['run_id'] / 'manifest.json').read_text())
            info = manifest.get('environment', {})
            writer.writerow({**row, **{key: info.get(key) for key in
                                      ('revision', 'controller_sha256', 'catalog_sha256')}})
    print('\nSaved summary: ' + str(DATA / 'results.csv'), flush=True)
    return rows


def setup():
    if platform.system() != 'Darwin':
        raise RuntimeError('This runner targets macOS. It is not the official container benchmark runner.')
    verify_sources()
    if not shutil.which('dot'):
        raise RuntimeError('First run: brew install graphviz')
    if not python_path().exists():
        subprocess.run([sys.executable, '-m', 'venv', str(ROOT / '.venv')], check=True)
    subprocess.run([str(python_path()), '-m', 'pip', 'install', 'graphviz==0.20.3', 'pytest==8.3.4'], check=True)
    env_info = environment()
    folder = DATA / 'setup' / dt.datetime.now().strftime('%Y%m%d-%H%M%S')
    folder.mkdir(parents=True)
    dump(folder / 'environment.json', env_info)
    selfcheck(env_info['codex_path'], folder / 'isolation')
    # Run the untouched public oracle only to validate the grading setup, never as model data.
    work = folder / 'oracle-workspace'
    work.mkdir()
    shutil.copyfile(SOURCE / 'environment/script.txt', work / 'script.txt')
    shutil.copyfile(SOURCE / 'oracle/solution.py', work / 'solution.py')
    process = run_process(sandbox_command(env_info['codex_path'], work, [str(python_path()), 'solution.py']),
                          work, folder, 'oracle', 60, env=clean_env(work))
    verification = grade(env_info['codex_path'], work, folder / 'oracle-verification', False)
    setup_pass = (process['exit_code'] == 0 and not process['timed_out']
                  and not process['interrupted'] and verification['upstream']['pass']
                  and verification['dot_syntax']['pass'])
    dump(folder / 'setup-result.json', {'pass': setup_pass, 'oracle_execution': process,
                                      'oracle_verification': verification})
    if not setup_pass:
        report = folder / 'oracle-verification/upstream.xml'
        details = ''
        if report.exists():
            for node in ET.parse(report).getroot().iter():
                if node.tag in ('error', 'failure'):
                    details = '\n' + ''.join(node.itertext())[-2000:]
                    break
        raise RuntimeError('Oracle fixture did not pass. No model run started. See ' + str(folder) + details)
    print('SETUP_PASS. Original oracle passes output tests; its text API mismatch is recorded separately.')
    print('Logs: ' + str(folder))


def require_setup(current):
    checks = sorted((DATA / 'setup').glob('*/setup-result.json'))
    if not checks or not json.loads(checks[-1].read_text()).get('pass'):
        raise RuntimeError('Complete setup first: both sandbox and oracle output checks must pass.')
    saved = json.loads((checks[-1].parent / 'environment.json').read_text())
    for key in ('controller_sha256', 'contract_sha256', 'catalog_sha256', 'prompt_sha256', 'codex_version',
                'ollama_version', 'dot_version', 'python_version'):
        if current.get(key) != saved.get(key):
            raise RuntimeError('Setup environment changed: ' + key + '. Run setup again.')


def smoke(model, timeout):
    """Small tool and skill-discovery check; never used as a study result."""
    info = environment()
    require_setup(info)
    installed = next((m for m in api('/api/tags')['models'] if m.get('name') == model), None)
    if installed is None:
        raise RuntimeError('Model is not installed: ' + model)
    model_info = api('/api/show', {'model': model})
    stamp = dt.datetime.now().strftime('%Y%m%d-%H%M%S')
    sample = {'values': [83, 76, 11, 29, 52, 76, 43, 12, 28, 41, 77, 34],
              'text': 'a\'b "quoted"\nnext\\path\n'}
    results = []
    for skill in (False, True):
        folder = DATA / 'smoke' / (stamp + '-' + model.replace(':', '_') +
                                  ('-with' if skill else '-without'))
        work = folder / 'workspace'
        work.mkdir(parents=True)
        dump(work / 'script.txt', sample)
        original = sha(work / 'script.txt')
        if skill:
            shutil.copytree(SOURCE / 'environment/skills/dialogue-graph', work / '.agents/skills/dialogue-graph')
        command, disabled = agent_command(info, model, work, skill)
        prompt = (
            'This is a toolchain installation check, not the research experiment. '
            'script.txt contains a JSON object. Read it with the shell. '
            'Create probe.py with a callable roundtrip(text) that returns text unchanged. '
            'Then run Python to call that function and compute sum(values). '
            'Write answer.json with keys total (integer), text (the unchanged text), '
            'and skill_names (the frontmatter name values in SKILL.md files under .agents/skills, '
            'or an empty list when that directory has no SKILL.md). '
            'For this check only, read each available SKILL.md before writing the answer. '
            'Keep script.txt unchanged. Use relative workspace paths; do not use /app. '
            f'Use {python_path()} for Python. Finish after creating and checking both files.'
        ).encode()
        dump(folder / 'manifest.json', {'purpose': 'setup check; excluded from experimental results',
             'model': model, 'model_digest': installed['digest'], 'with_skill': skill,
             'timeout_s': timeout, 'environment': info, 'command': command,
             'disabled_external_skills': disabled, 'prompt': prompt.decode()})
        dump(folder / 'model-show.json', model_info)
        print('\nSMOKE ' + str(folder), flush=True)
        execution = run_process(command, work, folder, 'agent', timeout,
                                stdin=prompt, env=clean_env(work, skill))
        (folder / 'agent.stdout').rename(folder / 'events.jsonl')
        events, bad = read_events(folder / 'events.jsonl')
        items = [e.get('item', {}) for e in events if e.get('type') == 'item.completed']
        errors = [i.get('message', '') for i in items if i.get('type') == 'error']
        stderr = (folder / 'agent.stderr').read_text(errors='replace')
        auth_error = any(s in stderr for s in ('HTTP 401', 'Failed to refresh token', 'unauthorized_unknown'))
        # Import the generated module only inside the same restricted sandbox.
        code = ('import importlib.util,json; from pathlib import Path\n'
                'raw=json.loads(Path("script.txt").read_text())\n'
                'answer=json.loads(Path("answer.json").read_text())\n'
                'spec=importlib.util.spec_from_file_location("probe", "probe.py")\n'
                'module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)\n'
                'assert module.roundtrip(raw["text"]) == raw["text"]\n'
                'assert type(answer["total"]) is int and answer["total"] == sum(raw["values"])\n'
                'assert answer["text"] == raw["text"]\n'
                'print("TOOLCHAIN_PASS", flush=True)\n'
                f'assert answer["skill_names"] == {(["dialogue-graph"] if skill else [])!r}\n'
                'print("ARTIFACT_PASS")\n')
        verification = run_process(sandbox_command(info['codex_path'], work,
            [str(python_path()), '-c', code], grading=True), work, folder, 'verification',
            60, env=clean_env(work, skill))
        completed = any(e.get('type') == 'turn.completed' for e in events)
        commands = [i for i in items if i.get('type') == 'command_execution']
        result = {'purpose': 'setup check; not an experimental result', 'model': model,
            'with_skill': skill, **execution, 'turn_completed': completed,
            'artifact_pass': verification['exit_code'] == 0, 'verification': verification,
            'core_artifact_pass': 'TOOLCHAIN_PASS' in (folder / 'verification.stdout').read_text(),
            'input_unchanged': sha(work / 'script.txt') == original,
            'auth_error': auth_error, 'unparsed_event_lines': bad, 'item_errors': errors,
            'command_calls': len(commands),
            'failed_commands': sum(c.get('exit_code') != 0 for c in commands)}
        result['toolchain_pass'] = (result['core_artifact_pass'] and result['input_unchanged'] and completed
            and execution['exit_code'] == 0 and not execution['timed_out']
            and not execution['interrupted'] and not auth_error and bad == 0
            and not any(not nonfatal_event_warning(e) for e in errors))
        result['pass'] = result['toolchain_pass'] and result['artifact_pass']
        dump(folder / 'result.json', result)
        print(json.dumps(result, indent=2, ensure_ascii=False), flush=True)
        results.append(result)
        if not result['toolchain_pass']:
            raise RuntimeError('SMOKE_FAIL. Inspect/export these short logs before starting a long pilot: ' + str(folder))
        if not result['pass']:
            print('SMOKE_NAME_WARNING: file reads, writes and code execution passed, but the reported '
                  'skill_names field differed. The strict check is retained as failed; review skill use in the pilot.')
    print('TOOLCHAIN_PASS. Both conditions passed the core tool check; strict name checks remain separately recorded.')


def freeze(weak, strong, repeats, timeout):
    if weak == strong or repeats < 1 or timeout < 1:
        raise RuntimeError('Use different models and positive repeats/timeout.')
    target = DATA / 'frozen.json'
    if target.exists():
        raise RuntimeError('A frozen plan already exists. Keep it and its runs; do not silently overwrite.')
    rows = summarize()
    pilots = {}
    for model in (weak, strong):
        selected = [r for r in rows if r['phase'] == 'pilot' and r['model'] == model]
        if not selected:
            raise RuntimeError('Missing pilot for ' + model)
        latest = max(json.loads((DATA / 'runs' / r['run_id'] / 'manifest.json').read_text())['batch'] for r in selected)
        pair = [r for r in selected if json.loads((DATA / 'runs' / r['run_id'] / 'manifest.json').read_text())['batch'] == latest]
        if len(pair) != 2 or {r['with_skill'] for r in pair} != {False, True}:
            raise RuntimeError('The latest pilot pair is incomplete for ' + model)
        pilots[model] = pair
    required = [r for r in pilots[weak] if r['with_skill']] + pilots[strong]
    if not all(r['eligible_success'] for r in required):
        raise RuntimeError('The desired case is not established by this pilot. Review the failures before freezing.')
    current = environment()
    digests = {}
    for model, pair in pilots.items():
        for result in pair:
            manifest = json.loads((DATA / 'runs' / result['run_id'] / 'manifest.json').read_text())
            for key in ('controller_sha256', 'contract_sha256', 'catalog_sha256', 'prompt_sha256', 'codex_version', 'ollama_version', 'dot_version', 'python_version'):
                if manifest['environment'].get(key) != current.get(key):
                    raise RuntimeError('Pilot configuration changed: ' + key)
            if manifest['timeout_s'] != timeout:
                raise RuntimeError('Pilot and formal time limits must match.')
            if model in digests and digests[model] != manifest['model_digest']:
                raise RuntimeError('Model changed during pilot: ' + model)
            digests[model] = manifest['model_digest']
    schedule = []
    rng = random.Random(20261008)
    # Block by model to avoid repeated model swapping; randomize within each repeated pair.
    for model in (weak, strong):
        for repeat in range(1, repeats + 1):
            conditions = [False, True]
            rng.shuffle(conditions)
            schedule.extend({'model': model, 'with_skill': skill, 'repeat': repeat} for skill in conditions)
    frozen = {'batch': 'formal-' + dt.datetime.now().strftime('%Y%m%d-%H%M%S'),
        'weak_candidate': weak, 'strong_candidate': strong, 'repeats': repeats, 'timeout_s': timeout,
        'schedule_seed': 20261008, 'schedule': schedule, 'model_digests': digests, 'environment': current,
        'selected_pilots': [r['run_id'] for pair in pilots.values() for r in pair],
        'all_pilots': [r['run_id'] for r in rows if r['phase'] == 'pilot'],
        'interpretation': 'Case chosen by pilot; formal repetitions are separate. Model labels are relative candidates.'}
    dump(target, frozen)
    print('Frozen ' + str(len(schedule)) + ' runs. Plan: ' + str(target))


def formal():
    frozen = json.loads((DATA / 'frozen.json').read_text())
    current = environment()
    for key in ('controller_sha256', 'contract_sha256', 'catalog_sha256', 'prompt_sha256', 'codex_version', 'ollama_version', 'dot_version', 'python_version'):
        if current.get(key) != frozen['environment'].get(key):
            raise RuntimeError('Frozen environment changed: ' + key)
    tags = {m['name']: m['digest'] for m in api('/api/tags')['models']}
    if any(tags.get(model) != digest for model, digest in frozen['model_digests'].items()):
        raise RuntimeError('Frozen model digest changed or model is missing.')
    finished = {}
    for path in (DATA / 'runs').glob('*/manifest.json'):
        manifest = json.loads(path.read_text())
        if manifest.get('batch') != frozen['batch']:
            continue
        if not (path.parent / 'result.json').exists():
            raise RuntimeError('Incomplete formal run exists: ' + str(path.parent) + '. Inspect it before restarting.')
        key = (manifest['model'], manifest['with_skill'], manifest['repeat'])
        if key in finished:
            raise RuntimeError('Duplicate formal run detected; inspect rather than discard.')
        finished[key] = manifest['run_id']
    for item in frozen['schedule']:
        key = (item['model'], item['with_skill'], item['repeat'])
        if key not in finished:
            run_trial(item['model'], item['with_skill'], 'formal', item['repeat'], frozen['timeout_s'], current, frozen['batch'])
    print('Formal schedule completed. Failed runs are retained and are included in results.csv.')


def write_run_summary(status):
    """Produce an evidence table for review; do not invent a research conclusion."""
    controller = sha(Path(__file__))
    rows = []
    for path in sorted((DATA / 'runs').glob('*/result.json')):
        manifest = json.loads((path.parent / 'manifest.json').read_text())
        if manifest.get('environment', {}).get('controller_sha256') == controller:
            rows.append(json.loads(path.read_text()))
    lines = ['# Local model skill study: run summary', '',
             'Status: ' + status, '',
             'This document is generated from saved run records. It is a working summary for trace review.', '',
             '## Configuration', '',
             'Codex + Ollama on native macOS; Qwen3.5 4B and 27B; dialogue-parser at pinned SkillsBench commit '
             '55bfe693f2a19f6b2f29aca3f54fe98b9d994668. The original input, skill, oracle and '
             'test assertions are unchanged. The shared task prompt clarifies that End is an external terminal '
             'target outside the JSON nodes list and that parse_script returns the saved graph. This clarification '
             'was introduced after an earlier pilot and is a separately reported task variant. '
             '/app is mapped to the run workspace. The custom local model '
             'catalog, standard skill rules, shell instructions and reasoning.effort=none request are shared '
             'by both models. Older configurations are retained in the archive and excluded from these tables.', '',
             'Success requires all 35 original output tests, the separate parse_script(text) check, valid DOT '
             'and unchanged input. Eligible pilot success additionally requires a normally completed session '
             'and clean integration checks.', '']
    for phase in ('pilot', 'formal'):
        selected = [r for r in rows if r['phase'] == phase]
        lines += ['## ' + phase.capitalize(), '',
                  '| Model | Skill | Successful tasks / runs | Eligible successes |',
                  '|---|---|---:|---:|']
        for model in ('qwen3.5:4b', 'qwen3.5:27b'):
            for skill in (False, True):
                group = [r for r in selected if r['model'] == model and r['with_skill'] == skill]
                lines.append(f'| {model} | {"with" if skill else "without"} | '
                             f'{sum(r["task_pass"] for r in group)} / {len(group)} | '
                             f'{sum(r["eligible_success"] for r in group)} |')
        lines += ['', '| Run | Original test score | Text API | DOT | Seconds | Commands | Failed commands | Timed out |',
                  '|---|---:|---|---|---:|---:|---:|---|']
        for r in selected:
            lines.append(f'| {r["run_id"]} | {r["upstream_score"]:.3f} | {r["contract_pass"]} | '
                         f'{r["dot_syntax_pass"]} | {r["elapsed_s"]:.3f} | {r["command_calls"]} | '
                         f'{r["failed_commands"]} | {r["timed_out"]} |')
        lines.append('')
    lines += ['## Interpretation limits', '',
              'This is a single-task case study selected through pilots. Pilot and formal runs must be reported '
              'separately, including failures. The skill condition includes its helper library, so differences '
              'cannot be attributed to the instruction text alone. Native macOS scores are not official container '
              'benchmark scores. Timings include startup and loading. Skill-name string counts do not prove skill '
              'use; inspect the raw tool commands and outputs. Missing token usage must remain missing. '
              'The none setting is a request to the backend, not direct observation of hidden reasoning.', '',
              'The final explanation should be written after inspecting the actual trajectories. No general '
              'claim about model capability or skill effectiveness is generated automatically.', '']
    DATA.mkdir(parents=True, exist_ok=True)
    (DATA / 'run_summary.md').write_text('\n'.join(lines))


def export_results():
    summarize()
    target = DATA.parent / ('dialogue-results-' + dt.datetime.now().strftime('%Y%m%d-%H%M%S') + '.zip')
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(DATA.rglob('*')):
            if path.is_file():
                archive.write(path, path.relative_to(DATA.parent))
        # The same archive includes the exact reproducible code; no venv or personal config.
        names = ['study.py', 'contract_check.py', 'README.md', 'task_prompt.txt',
                 'source_manifest.json', 'local_models.json']
        names += [str(p.relative_to(ROOT)) for p in SOURCE.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts and p.suffix != '.pyc']
        for name in sorted(names):
            archive.write(ROOT / name, 'reproduction/skill_study/' + name)
    print('\nRESULT_ARCHIVE: ' + str(target), flush=True)
    return target


def run_all():
    """Run the authorized workflow once, stopping early on a blocking case."""
    status, stage = 'in progress', 'setup'
    try:
        if (DATA / 'frozen.json').exists():
            stage = 'resume formal schedule'
            formal()
        else:
            controller = sha(Path(__file__))
            for path in (DATA / 'runs').glob('*/manifest.json'):
                m = json.loads(path.read_text())
                if m.get('environment', {}).get('controller_sha256') == controller:
                    raise RuntimeError('Runs from this exact configuration already exist. They are retained; '
                                       'automatic retries are blocked so failed attempts are not silently replaced.')
            print('\n[1/5] Setup, sandbox, large heredoc and reference checks', flush=True)
            setup()
            installed = {m.get('name') for m in api('/api/tags')['models']}
            missing = {'qwen3.5:4b', 'qwen3.5:27b'} - installed
            if missing:
                raise RuntimeError('Required models missing: ' + ', '.join(sorted(missing)))
            stage = 'short toolchain checks'
            print('\n[2/5] Short checks for both models', flush=True)
            smoke('qwen3.5:4b', 180)
            smoke('qwen3.5:27b', 180)
            info = environment()
            require_setup(info)
            batch = dt.datetime.now().strftime('%Y%m%d-%H%M%S')
            stage = 'pilot'
            print('\n[3/5] Pilot; test required success conditions first', flush=True)
            for model, skill in [('qwen3.5:27b', False), ('qwen3.5:27b', True),
                                 ('qwen3.5:4b', True), ('qwen3.5:4b', False)]:
                result = run_trial(model, skill, 'pilot', batch, 900, info, batch)
                required = model == 'qwen3.5:27b' or skill
                if required and not result['eligible_success']:
                    raise RuntimeError('Required pilot condition failed: ' + model +
                                       (' with skill' if skill else ' without skill') +
                                       '. Remaining model runs stopped; evidence retained.')
            stage = 'freeze'
            print('\n[4/5] Freeze successful case and configuration', flush=True)
            freeze('qwen3.5:4b', 'qwen3.5:27b', 3, 900)
            stage = 'formal repetitions'
            print('\n[5/5] Twelve formal runs; every completed failure is retained', flush=True)
            formal()
        status = 'formal schedule completed; inspect results and trajectories before drawing conclusions'
        print('\nSTUDY_COMPLETE: formal runs and evidence saved.', flush=True)
    except Exception as exc:
        status = 'stopped at ' + stage + ': ' + str(exc)
        raise
    except KeyboardInterrupt:
        status = 'interrupted at ' + stage
        raise
    finally:
        DATA.mkdir(parents=True, exist_ok=True)
        dump(DATA / 'execution_status.json', {'status': status, 'stage': stage,
             'revision': REVISION, 'updated_at': dt.datetime.now().astimezone().isoformat()})
        write_run_summary(status)
        export_results()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='action', required=True)
    sub.add_parser('setup')
    sub.add_parser('all', help='Run setup, short checks, pilots, freeze, repetitions and export once.')
    check = sub.add_parser('smoke')
    check.add_argument('--model', default='qwen3.5:4b')
    check.add_argument('--timeout', type=int, default=180)
    pilot = sub.add_parser('pilot')
    pilot.add_argument('--model', required=True)
    pilot.add_argument('--timeout', type=int, default=900)
    pilot.add_argument('--order', choices=['with-first', 'without-first'], default='without-first')
    sub.add_parser('summarize')
    sub.add_parser('export')
    plan = sub.add_parser('freeze')
    plan.add_argument('--weak', default='qwen3.5:4b')
    plan.add_argument('--strong', default='qwen3.5:27b')
    plan.add_argument('--repeats', type=int, default=3)
    plan.add_argument('--timeout', type=int, default=900)
    sub.add_parser('formal')
    args = parser.parse_args()
    if args.action == 'all':
        run_all()
    elif args.action == 'setup':
        setup()
    elif args.action == 'smoke':
        if args.timeout <= 0:
            parser.error('--timeout must be positive')
        smoke(args.model, args.timeout)
    elif args.action == 'pilot':
        if args.timeout <= 0:
            parser.error('--timeout must be positive')
        info = environment()
        require_setup(info)
        batch = dt.datetime.now().strftime('%Y%m%d-%H%M%S')
        order = [False, True] if args.order == 'without-first' else [True, False]
        for skill in order:
            run_trial(args.model, skill, 'pilot', batch, args.timeout, info, batch)
        print('\nPilot complete. Keep both runs, including failures. Review before formal repetitions.')
    elif args.action == 'summarize':
        summarize()
    elif args.action == 'freeze':
        freeze(args.weak, args.strong, args.repeats, args.timeout)
    elif args.action == 'formal':
        formal()
    else:
        export_results()


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as exc:
        print('ERROR: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
